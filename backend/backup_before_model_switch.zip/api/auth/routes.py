from fastapi import APIRouter, HTTPException, status, Request
from pydantic import BaseModel
from datetime import datetime, timedelta
from jose import jwt

DEMO_USER = {"username": "admin", "password": "12345"}

SECRET_KEY = "lyntos_secret_key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

router = APIRouter(prefix="/v1/auth", tags=["auth"])

class Token(BaseModel):
    access_token: str
    token_type: str

@router.post("/login", response_model=Token)
async def login(request: Request):
    try:
        body = await request.body()
        print("RAW BODY:", body)
        data = await request.json()
        print("PARSED JSON:", data)
    except Exception as e:
        print("JSON ERROR:", e)
        raise HTTPException(status_code=400, detail="Invalid request format")

    username = data.get("username")
    password = data.get("password")
    print("USERNAME:", username, "PASSWORD:", password)

    if username != DEMO_USER["username"] or password != DEMO_USER["password"]:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Kullanıcı adı veya şifre hatalı")

    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {"sub": username, "exp": expire}
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return {"access_token": encoded_jwt, "token_type": "bearer"}

