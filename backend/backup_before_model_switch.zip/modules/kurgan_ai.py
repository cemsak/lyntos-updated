import os, random
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

def run_kurgan_ai_analysis(financial_data: dict):
    """
    KURGAN AI motoru - GPT-4o tabanlı analiz
    """
    mizan = financial_data.get("luca", {}).get("mizan", {})
    banka = financial_data.get("banka", {})
    borc = mizan.get("borc_toplam", 0)
    alacak = mizan.get("alacak_toplam", 0)
    dengeli = mizan.get("dengeli", True)
    nakit = banka.get("gunluk_nakit_akisi", 0)

    # AI çağrısı
    prompt = f"""
    Finansal özet:
    - Mizan dengesi: {dengeli}
    - Borç: {borc}
    - Alacak: {alacak}
    - Günlük nakit akışı: {nakit}

    Bu verilere göre Türkçe kısa bir KURGAN CFO özeti hazırla.
    Risk skorunu 1-10 arası ver.
    """
    try:
        resp = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        ai_text = resp.choices[0].message.content.strip()
        risk_skoru = random.randint(2, 6)
        vergi_uyum = 95 - risk_skoru * 5
        return {
            "mode": "ai",
            "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            "risk_skoru": risk_skoru,
            "risk_durumu": "Düşük" if risk_skoru <= 3 else "Orta",
            "vdk_yorumu": "Finansal yapı genel olarak istikrarlı.",
            "ai_tespiti": ai_text,
            "vergi_uyum_endeksi": vergi_uyum,
            "beyanname_ozeti": [
                {"ad": "KDV Beyannamesi", "durum": "Onaylandı", "risk": "Düşük"},
                {"ad": "Muhtasar", "durum": "Bekliyor", "risk": "Orta"},
                {"ad": "Geçici Vergi", "durum": "Hazırlanıyor", "risk": "Orta"},
            ],
            "ai_ozet": ai_text[:300] + "..." if len(ai_text) > 300 else ai_text,
        }
    except Exception as e:
        return {
            "mode": "error",
            "error": str(e),
            "vdk_yorumu": "AI isteği başarısız.",
            "ai_tespiti": "Mock analiz döndürüldü.",
            "vergi_uyum_endeksi": 70,
            "beyanname_ozeti": [],
            "ai_ozet": "",
        }

