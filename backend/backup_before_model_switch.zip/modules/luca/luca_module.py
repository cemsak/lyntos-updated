import datetime

def get_luca_status():
    """LUCA sistemine bağlantı testi (mock)."""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Simülasyon verisi
    mizan_summary = {
        "toplam_hesap": 256,
        "borc_toplam": 420000.50,
        "alacak_toplam": 420000.50,
        "dengeli": True
    }

    banka_summary = {
        "banka_sayisi": 3,
        "toplam_hareket": 1542,
        "son_islem": "2025-10-15 18:20:00",
        "nakit_akisi": "pozitif"
    }

    return {
        "system": "LUCA",
        "status": "Online",
        "last_check": now,
        "message": "LUCA muhasebe verileri başarıyla alındı (mock).",
        "mizan": mizan_summary,
        "banka": banka_summary
    }

