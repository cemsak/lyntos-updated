import datetime
import random

def get_kurgan_analysis(data):
    """
    VDK + KURGAN Risk Analiz Motoru (mock - akıllı sürüm)
    GİB, LUCA, BANKA, NACE verilerinden risk puanı hesaplar.
    """

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    gib = data.get("gib", {})
    luca = data.get("luca", {})
    banka = data.get("banka", {})
    nace = data.get("nace", {})

    risk_puan = 0
    yorumlar = []

    # --- GİB analizi ---
    if "e-Defter" in gib.get("message", ""):
        yorumlar.append("GİB e-Defter bağlantısı sorunsuz.")
    else:
        risk_puan += 10
        yorumlar.append("GİB bağlantısında anormallik tespit edildi.")

    # --- LUCA analizi ---
    mizan = luca.get("mizan", {})
    if not mizan.get("dengeli", True):
        risk_puan += 20
        yorumlar.append("Mizan dengesi bozuk.")
    else:
        yorumlar.append("Mizan dengesi normal.")

    # --- BANKA analizi ---
    banka_detay = banka.get("detaylar", [])
    if banka.get("gunluk_nakit_akisi", 0) < 0:
        risk_puan += 25
        yorumlar.append("Negatif nakit akışı riski tespit edildi.")
    else:
        yorumlar.append("Nakit akışı pozitif seyrediyor.")

    # --- NACE analizi ---
    nace_perf = nace.get("performans_durumu", {})
    if nace_perf.get("durum") == "Altında":
        risk_puan += 15
        yorumlar.append("Sektör performansının altında seyrediyor.")
    else:
        yorumlar.append("Sektör ortalamasının üzerinde performans.")

    # --- VDK veri seti eşleştirmesi (mock scoring) ---
    vdk_parametreleri = {
        "kdv_farki": random.uniform(0, 10),
        "beyan_gecikmesi": random.choice([True, False]),
        "borc_artisi": random.uniform(0, 0.5),
        "faaliyet_dalgalanmasi": random.uniform(0, 1)
    }

    if vdk_parametreleri["kdv_farki"] > 7:
        risk_puan += 10
        yorumlar.append("KDV farkı sektör ortalamasının üzerinde (%{:.1f}).".format(vdk_parametreleri["kdv_farki"]))
    if vdk_parametreleri["beyan_gecikmesi"]:
        risk_puan += 5
        yorumlar.append("Son beyan dönemi gecikmeli gönderilmiş olabilir.")
    if vdk_parametreleri["borc_artisi"] > 0.3:
        risk_puan += 10
        yorumlar.append("Kısa vadeli borçlarda %30'dan fazla artış mevcut.")

    # --- Son skor ve yorum ---
    risk_puan = min(100, risk_puan)
    risk_durumu = "Düşük" if risk_puan < 30 else "Orta" if risk_puan < 60 else "Yüksek"

    analiz_raporu = {
        "system": "VDK/KURGAN",
        "status": "Online",
        "last_check": now,
        "risk_skoru": risk_puan,
        "risk_durumu": risk_durumu,
        "yorumlar": yorumlar,
        "vdk_parametreleri": vdk_parametreleri,
        "message": "KURGAN Risk Analizi tamamlandı (yapay zeka simülasyonu)."
    }

    return analiz_raporu

