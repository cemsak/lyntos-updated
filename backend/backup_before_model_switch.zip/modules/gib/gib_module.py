import datetime

def get_gib_status():
    """GİB sistemine bağlantı testi (mock)."""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return {
        "system": "GİB",
        "status": "Online",
        "last_check": now,
        "message": "e-Defter API bağlantısı başarılı (test modunda)."
    }

