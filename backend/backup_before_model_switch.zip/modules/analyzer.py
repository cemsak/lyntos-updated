from modules.gib.gib_module import get_gib_status
from modules.luca.luca_module import get_luca_status
from modules.banka.banka_module import get_banka_status
from modules.tobb.nace_module import get_nace_status
from modules.kurgan.kurgan_module import get_kurgan_analysis

def collect_all_data():
    """Tüm modüllerden durum, veri ve risk analizini toplar."""
    gib = get_gib_status()
    luca = get_luca_status()
    banka = get_banka_status()
    nace = get_nace_status()

    # Tüm verileri birleştir
    dataset = {
        "gib": gib,
        "luca": luca,
        "banka": banka,
        "nace": nace
    }

    # KURGAN analizi
    kurgan = get_kurgan_analysis(dataset)

    return {
        "gib": gib,
        "luca": luca,
        "banka": banka,
        "nace": nace,
        "kurgan": kurgan,
        "summary": "Tüm sistem analizi tamamlandı (KURGAN dahil)."
    }

