import datetime

def get_nace_status():
    """TOBB / ALTSO / NACE sektör verisi test modülü."""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Örnek sektör verileri (mock)
    firma_bilgileri = {
        "unvan": "Hakkı Özkan SMMM",
        "nace_kodu": "69.20.02",
        "sektor": "Muhasebe ve Mali Müşavirlik Faaliyetleri",
        "bolge": "Alanya / Antalya"
    }

    # Bölgesel ortalama göstergeler (örnek)
    sektor_endeksleri = {
        "ortalama_karlilik": 0.22,
        "ortalama_borc_orani": 0.38,
        "ortalama_risk_skoru": 68
    }

    # Firmanın (LUCA + BANKA verilerinden hesaplanmış olabilecek) özet performansı
    firma_gercekleri = {
        "net_kar_marji": 0.27,
        "borc_orani": 0.35,
        "risk_skoru": 82
    }

    # Performans değerlendirmesi
    fark = round((firma_gercekleri["risk_skoru"] - sektor_endeksleri["ortalama_risk_skoru"]), 2)
    durum = "Üstünde" if fark > 0 else "Altında"

    return {
        "system": "TOBB/ALTSO/NACE",
        "status": "Online",
        "last_check": now,
        "firma": firma_bilgileri,
        "sektor_endeksleri": sektor_endeksleri,
        "firma_gercekleri": firma_gercekleri,
        "performans_durumu": {
            "fark": fark,
            "durum": durum,
            "performans_skoru": firma_gercekleri["risk_skoru"]
        },
        "message": "Sektör kıyaslaması başarıyla tamamlandı (mock)."
    }

