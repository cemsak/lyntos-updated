import datetime

def get_banka_status():
    """Banka entegrasyonu test modülü."""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Örnek işlem verileri
    hesaplar = [
        {"banka": "Garanti BBVA", "bakiye": 125430.75, "son_islem": "2025-10-16 12:30"},
        {"banka": "İş Bankası", "bakiye": 89050.10, "son_islem": "2025-10-16 09:45"},
        {"banka": "Ziraat Bankası", "bakiye": 34200.00, "son_islem": "2025-10-15 17:10"},
    ]

    toplam_bakiye = sum(h["bakiye"] for h in hesaplar)
    gunluk_nakit_akisi = round((hesaplar[0]["bakiye"] - hesaplar[-1]["bakiye"]) / 3, 2)

    return {
        "system": "BANKA",
        "status": "Online",
        "last_check": now,
        "message": "Banka entegrasyonu test modu aktif.",
        "hesap_sayisi": len(hesaplar),
        "toplam_bakiye": toplam_bakiye,
        "gunluk_nakit_akisi": gunluk_nakit_akisi,
        "detaylar": hesaplar
    }

