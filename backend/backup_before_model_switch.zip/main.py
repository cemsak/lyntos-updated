import os, json
import jwt  # JSON Web Token (PyJWT)
from typing import Optional
from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from datetime import datetime, timedelta
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from openai import OpenAI
from services.radar_engine import calculate_radar_score
from services.ai_alerts import generate_ai_alerts

# === META VERSİYON ===
API_VERSION = "1.0"
SCHEMA_VERSION = "2025-10-18"

# === .env ===
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

# === APP ===
app = FastAPI(title="LYNTOS SMMM Enterprise Backend vFull")

# === CORS ===
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === OpenAI ===
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# ========== AUTH ==========

class LoginRequest(BaseModel):
    username: str
    password: str

@app.post("/v1/auth/login")
def login(req: LoginRequest):
    user = os.getenv("ADMIN_USER", "admin")
    pw = os.getenv("ADMIN_PASS", "12345")
    if req.username == user and req.password == pw:
        return {"access_token": "demo-token-123", "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Unauthorized")
# === JWT tabanlı oturum (ek) ===
SECRET_KEY = "lyntos_secret_key_2025"
ALGORITHM = "HS256"

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/v1/auth/token")

@app.post("/v1/auth/token")
def login_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = os.getenv("ADMIN_USER", "admin")
    pw = os.getenv("ADMIN_PASS", "12345")

    if form_data.username == user and form_data.password == pw:
        expire = datetime.utcnow() + timedelta(hours=4)
        to_encode = {"sub": form_data.username, "exp": expire}
        token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return {"access_token": token, "token_type": "bearer"}

    raise HTTPException(status_code=401, detail="Kullanıcı adı veya şifre hatalı")

@app.get("/v1/auth/me")
def read_users_me(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return {"username": payload.get("sub")}
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token süresi doldu")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Geçersiz token")


@app.post("/v1/auth/register")
def register(user: LoginRequest):
    USERS_DB = "users.json"
    if not os.path.exists(USERS_DB):
        with open(USERS_DB, "w") as f:
            json.dump([], f)
    with open(USERS_DB, "r") as f:
        users = json.load(f)
    for u in users:
        if u["username"] == user.username:
            raise HTTPException(status_code=400, detail="Kullanıcı zaten var.")
    users.append({"username": user.username, "password": user.password})
    with open(USERS_DB, "w") as f:
        json.dump(users, f)
    return {"message": f"Kullanıcı oluşturuldu: {user.username}"}


# ========== HEALTH ==========

@app.get("/health")
def health():
    return {"status": "ok", "message": "LYNTOS Backend aktif"}


# ========== LUCA MOCK ==========

@app.get("/v1/luca/data")
def get_luca_data(firma: str = Query(...), donem: str = Query(...)):
    return {
        "firma": firma,
        "donem": donem,
        "mizan": {"borc_toplam": 420000.5, "alacak_toplam": 420000.5},
        "beyanname": [
            {"ad": "KDV", "durum": "Onaylandı", "risk": "Düşük"},
            {"ad": "Muhtasar", "durum": "Bekliyor", "risk": "Orta"},
            {"ad": "Geçici Vergi", "durum": "Hazırlanıyor", "risk": "Orta"},
        ],
        "nakit": {"gunluk": 30410.25, "banka_sayisi": 3},
        "nace": {"performans_skoru": 82, "durum": "Sektör Üstü"},
        "kurgan": {
            "mode": "ai_real",
            "model": "gpt-4o-mini",
            "risk_skoru": 3,
            "risk_durumu": "Düşük",
            "vdk_yorumu": "Finansal yapı genel olarak istikrarlı.",
            "ai_tespiti": "Veri bütünlüğü yüksek, dijital uyum sorunsuz.",
            "vergi_uyum_endeksi": 80,
        },
    }


# ========== KURGAN ANALİZ ==========

@app.get("/v1/kurgan/analyze")
def analyze(entity: Optional[str] = Query(None), period: Optional[str] = Query(None)):
    unvan_map = {
        "HKOZKAN": "Hakkı Özkan SMMM",
        "OZKANLAR": "Özkanlar İnşaat AŞ",
        "DEMO": "Demo Mükellef",
        None: "Hakkı Özkan SMMM",
    }
    unvan = unvan_map.get(entity, "Hakkı Özkan SMMM")
    donem = period or "2025-Q4"

    # --- Ana veriler ---
    mizan_borc, mizan_alacak = 420_000.50, 420_000.50
    mizan_dengeli = abs(mizan_borc - mizan_alacak) < 0.01

    bankalar = [
        {"banka": "Garanti BBVA", "bakiye": 125_430.75},
        {"banka": "İş Bankası", "bakiye": 89_050.10},
        {"banka": "Ziraat", "bakiye": 34_200.00},
    ]
    banka_toplam = round(sum(b["bakiye"] for b in bankalar), 2)

    beyanlar = [
        {"ad": "KDV Beyannamesi", "durum": "Onaylandı", "risk": "Düşük"},
        {"ad": "Muhtasar", "durum": "Bekliyor", "risk": "Orta"},
        {"ad": "Geçici Vergi", "durum": "Hazırlanıyor", "risk": "Orta"},
    ]

    # --- Ek görselleştirilebilir veri ---
    partner_top5 = [
        {"unvan": "Alpha Ltd.", "nace": "46.90.01", "kdv_orani": "%20", "fatura_sayisi": 18, "uyum_puani": 92},
        {"unvan": "Beta A.Ş.", "nace": "47.19.09", "kdv_orani": "%10", "fatura_sayisi": 11, "uyum_puani": 81},
        {"unvan": "Gamma Ltd.", "nace": "62.01.01", "kdv_orani": "%20", "fatura_sayisi": 6, "uyum_puani": 74},
        {"unvan": "Delta A.Ş.", "nace": "41.20.02", "kdv_orani": "%1", "fatura_sayisi": 9, "uyum_puani": 66},
        {"unvan": "Epsilon Ltd.", "nace": "69.20.02", "kdv_orani": "%20", "fatura_sayisi": 7, "uyum_puani": 58},
    ]

    borc_alacak_trend = [
        {"ay": "May", "borc": 380, "alacak": 375},
        {"ay": "Haz", "borc": 395, "alacak": 392},
        {"ay": "Tem", "borc": 405, "alacak": 404},
        {"ay": "Ağu", "borc": 415, "alacak": 413},
        {"ay": "Eyl", "borc": 420, "alacak": 420},
        {"ay": "Eki", "borc": 421, "alacak": 420},
    ]

    banka_sparkline = [245, 246, 244, 247, 249, 248, 250, 249, 251, 250, 252, 251, 253, 252, 254, 253, 255, 254, 256, 255, 257, 258, 257, 259, 260, 261, 262, 263]

    risk_log = [
        {"donem": "2025-Q2", "skor": 5},
        {"donem": "2025-Q3", "skor": 4},
        {"donem": "2025-Q4", "skor": 4},
    ]

    uyum_kontrol = {
        "banka_mizan_tutarliligi": {
            "durum": mizan_dengeli and banka_toplam > 0,
            "detay": f"Banka toplamı ₺{banka_toplam:,.2f} | Mizan dengesi: {'Evet' if mizan_dengeli else 'Hayır'}",
        },
        "beyannameler_mizan_tutarliligi": {"durum": True, "detay": "KDV ve Muhtasar beyanları mizan ile uyumlu."},
        "son_beyan_gonderimi": {"kdv": "Zamanında", "muhtasar": "Bekliyor", "gecici_vergi": "Hazırlanıyor"},
    }

    risk_nedenleri = [
        {"baslik": "Mizan dengesi", "etki": "Düşürücü", "kanit": f"Borç=Alacak (₺{mizan_borc:,.2f})"},
        {"baslik": "Nakit akışı", "etki": "Düşürücü", "kanit": "Günlük akış pozitif"},
        {"baslik": "Beyan disiplini", "etki": "Nötr/Artırıcı", "kanit": "Muhtasar bekliyor → kısa süreli izleme"},
    ]

    karsi_firma = [
        {"unvan": "Alfa Yazılım", "vergi_no": "1122334455", "risk": "Düşük", "durum": "Uygun"},
        {"unvan": "Beta Metal", "vergi_no": "9988776655", "risk": "Yüksek", "durum": "İnceleme"},
    ]

    data = {
        "summary": f"{unvan} | Dönem: {donem}",
        "gib": {"system": "GİB", "status": "Online", "message": "e-Defter API (demo)."},
        "luca": {"system": "LUCA", "status": "Online", "message": "Mizan okundu (demo).",
                 "mizan": {"toplam_hesap": 256, "borc_toplam": mizan_borc, "alacak_toplam": mizan_alacak, "dengeli": mizan_dengeli}},
        "banka": {"system": "BANKA", "status": "Online", "toplam_bakiye": banka_toplam,
                  "gunluk_nakit_akisi": 30_410.25, "detaylar": bankalar},
        "nace": {"system": "TOBB/ALTSO/NACE", "status": "Online", "performans_skoru": 82, "durum": "Sektör Üstü"},
        "kurgan": {
            "mode": "ai",
            "model": OPENAI_MODEL,
            "risk_skoru": 4,
            "risk_durumu": "Düşük",
            "risk_nedenleri": risk_nedenleri,
            "vergi_uyum_endeksi": 85,
            "vdk_yorumu": "Finansal yapı istikrarlı.",
            "ai_tespiti": "Mizan dengesi ve nakit akışı güçlü.",
            "beyanname_ozeti": beyanlar,
            "uyum_kontrol": uyum_kontrol,
            "karsi_firma": karsi_firma,
            "risk_log": risk_log,
        },
        "partner_top5": partner_top5,
        "borc_alacak_trend": borc_alacak_trend,
        "banka_sparkline": banka_sparkline,
        "filters": {"entity": entity or "HKOZKAN", "period": donem},
    }
    # --- RADAR Analizi (v2.1) ---
    try:
        radar_result = calculate_radar_score(data)
        data["radar"] = {
            "radar_risk_skoru": radar_result.get("radar_risk_skoru", 0),
            "radar_risk_durumu": radar_result.get("radar_risk_durumu", "Bilinmiyor"),
            "nedenler": radar_result.get("nedenler", []),
            "oneriler": radar_result.get("oneriler", []),
            "bilesen_puanlari": radar_result.get("bilesen_puanlari", {})
        }
    except Exception as e:
        print(f"[RADAR] Analiz hatası: {e}")
        data["radar"] = {   
            "radar_risk_skoru": 0,
            "radar_risk_durumu": "Hata",
            "nedenler": [],
            "oneriler": []
        }

    # --- AI Risk Uyarıları (sağ panel) ---
    try:
        ai_alerts = generate_ai_alerts(data)
        data["ai_alerts"] = ai_alerts
    except Exception as e:
        print(f"[AI ALERTS] Hata: {e}")
        data["ai_alerts"] = {"uyarilar": []}

    return _ensure_defaults(data)   # ✅ tam 4 boşluk içeride olmalı


# ========== META ==========
@app.get("/v1/meta/options")
def meta_options():
    return {
        "entities": [
            {"id": "HKOZKAN", "unvan": "Hakkı Özkan SMMM"},
            {"id": "OZKANLAR", "unvan": "Özkanlar İnşaat AŞ"},
            {"id": "DEMO", "unvan": "Demo Mükellef"},
        ],
        "periods": ["2025-Q4", "2025-Q3", "2025-10", "2025"],
    }


# ========== DEFAULT HELPER ==========
def _ensure_defaults(payload: dict) -> dict:
    def merge(dst, src):
        if isinstance(dst, dict) and isinstance(src, dict):
            out = dict(dst)
            for k, v in src.items():
                out[k] = merge(dst.get(k), v)
            return out
        return src if src is not None else dst

    defaults = {
        "summary": "",
        "gib": {"system": "GİB", "status": "Unknown", "message": ""},
        "luca": {"system": "LUCA", "status": "Unknown", "message": "",
                 "mizan": {"toplam_hesap": 0, "borc_toplam": 0.0, "alacak_toplam": 0.0, "dengeli": False}},
        "banka": {"system": "BANKA", "status": "Unknown", "toplam_bakiye": 0.0,
                  "gunluk_nakit_akisi": 0.0, "hesap_sayisi": 0, "detaylar": []},
        "nace": {"system": "TOBB/ALTSO/NACE", "status": "Unknown", "performans_skoru": 0, "durum": ""},
        "kurgan": {"mode": "", "model": "", "risk_skoru": 0, "risk_durumu": "", "risk_nedenleri": [],
                   "vergi_uyum_endeksi": 0, "vdk_yorumu": "", "ai_tespiti": "", "beyanname_ozeti": [],
                   "uyum_kontrol": {}, "karsi_firma": [], "risk_log": []},
        "partner_top5": [],
        "borc_alacak_trend": [],
        "banka_sparkline": [],
        "filters": {"entity": "", "period": ""},
        "_meta": {"api_version": API_VERSION, "schema_version": SCHEMA_VERSION},
    }

    return merge(defaults, payload or {})
import csv

@app.get("/v1/banka/load")
def load_banka_data():
    """
    connectors/banka klasöründeki CSV verilerini okur ve toplu bakiye döner.
    """
    csv_path = "connectors/banka/banka_demo.csv"

    if not os.path.exists(csv_path):
        raise HTTPException(status_code=404, detail="Banka CSV dosyası bulunamadı.")

    data = []
    gelir_toplam = 0
    gider_toplam = 0

    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            row["tutar"] = float(row["tutar"])
            data.append(row)
            if row["tip"] == "GELIR":
                gelir_toplam += row["tutar"]
            elif row["tip"] == "GIDER":
                gider_toplam += abs(row["tutar"])

    toplam_bakiye = gelir_toplam - gider_toplam

    return {
        "status": "ok",
        "toplam_kayit": len(data),
        "gelir_toplam": gelir_toplam,
        "gider_toplam": gider_toplam,
        "toplam_bakiye": toplam_bakiye,
        "veriler": data
    }

# --- Varsayılan alanları garanti eden fonksiyon ---
def _ensure_defaults(payload: dict) -> dict:
    defaults = {
        "summary": "",
        "gib": {"system": "GİB", "status": "Unknown", "message": ""},
        "luca": {
            "system": "LUCA",
            "status": "Unknown",
            "message": "",
            "mizan": {
                "toplam_hesap": 0,
                "borc_toplam": 0.0,
                "alacak_toplam": 0.0,
                "dengeli": False,
            },
        },
        "banka": {
            "system": "BANKA",
            "status": "Unknown",
            "toplam_bakiye": 0.0,
            "gunluk_nakit_akisi": 0.0,
            "hesap_sayisi": 0,
            "detaylar": [],
        },
        "nace": {
            "system": "TOBB/ALTSO/NACE",
            "status": "Unknown",
            "performans_skoru": 0,
            "durum": "",
        },
        "kurgan": {
            "mode": "mock",
            "model": "",
            "risk_skoru": 0,
            "risk_durumu": "",
            "risk_nedenleri": [],
            "vergi_uyum_endeksi": 0,
            "vdk_yorumu": "",
            "ai_tespiti": "",
            "beyanname_ozeti": [],
            "uyum_kontrol": {
                "banka_mizan_tutarliligi": {"durum": False, "detay": ""},
                "beyannameler_mizan_tutarliligi": {"durum": False, "detay": ""},
                "son_beyan_gonderimi": {"kdv": "", "muhtasar": "", "gecici_vergi": ""},
            },
            "karsi_firma": [],
        },
        "filters": {"entity": "", "period": ""},
        "_meta": {"api_version": "1.0", "schema_version": "2025-10-17"},
    }

    def merge(dst, src):
        if isinstance(dst, dict) and isinstance(src, dict):
            out = dict(dst)
            for k, v in src.items():
                out[k] = merge(dst.get(k), v)
            return out
        return src if src is not None else dst

    return merge(defaults, payload or {})

# --- Yeni endpoint: AI Risk Uyarıları ---
@app.get("/v1/kurgan/alerts")
def get_kurgan_alerts(entity: str = "HKOZKAN", period: str = "2025-Q4"):
    """
    AI Risk Uyarıları — DashboardV3 sağ panelde görünür.
    CSV/LUCA verisine dayalıdır (şimdilik). 1 dk cache uygulanır.
    """
    from services.ai_engine import generate_ai_alerts
    from services.simple_cache import get_cache, set_cache

    cache_key = f"alerts_{entity}_{period}"
    cached = get_cache(cache_key)
    if cached:
        return {"cached": True, "alerts": cached}

    alerts = generate_ai_alerts(entity, period)
    set_cache(cache_key, alerts, ttl=60)
    return {"cached": False, "alerts": alerts}

