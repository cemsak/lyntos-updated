# ~/lyntos/backend/services/reconciliation.py
from connectors.luca_client import get_mizan, get_beyan_ozeti
from connectors.banka_client import get_banka_ozet

def check_consistency(firma: str, period: str):
    """
    LUCA + Banka + Beyanname tutarlılığını kontrol eder.
    Dönen veri Dashboard’un “Uyum Kartları” kısmını besler.
    """
    mizan = get_mizan(firma, period)
    banka = get_banka_ozet(firma, period)
    beyanlar = get_beyan_ozeti(firma, period)

    uyum = {
        "banka_mizan_tutarliligi": {
            "durum": abs(mizan["borc_toplam"] - mizan["alacak_toplam"]) < 1 and banka["toplam_bakiye"] > 0,
            "detay": f"Banka Toplamı ₺{banka['toplam_bakiye']:,} | Mizan dengesi {'evet' if mizan['dengeli'] else 'hayır'}"
        },
        "beyannameler_mizan_tutarliligi": {
            "durum": all(b["risk"] != "Yüksek" for b in beyanlar),
            "detay": "Beyannamelerde yüksek risk yok."
        },
        "son_beyan_gonderimi": {
            "kdv": next((b["durum"] for b in beyanlar if "KDV" in b["ad"]), "Bilinmiyor"),
            "muhtasar": next((b["durum"] for b in beyanlar if "Muhtasar" in b["ad"]), "Bilinmiyor"),
            "gecici_vergi": next((b["durum"] for b in beyanlar if "Geçici" in b["ad"]), "Bilinmiyor")
        }
    }
    return uyum

