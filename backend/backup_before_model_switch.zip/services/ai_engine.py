# ~/lyntos/backend/services/ai_engine.py
import random
from typing import List, Dict

def generate_ai_alerts(firma: str, period: str) -> List[Dict[str, str]]:
    """
    CSV veya LUCA verisine göre risk uyarısı üretir.
    Şimdilik mock + zeki rastgelelik içeriyor.
    """
    alerts = [
        {
            "kategori": "Beyanname Uyum Riski",
            "aciklama": "Son 3 ayda muhtasar beyan gecikmesi gözlendi.",
            "seviye": "Orta"
        },
        {
            "kategori": "Nakit Akışı Anomali Riski",
            "aciklama": "Nakit akışı 5 günde %25 azaldı.",
            "seviye": "Yüksek"
        },
        {
            "kategori": "Fatura / Cari Risk",
            "aciklama": "Alış/satış oranı 0.45’e düştü — stok şişmesi riski.",
            "seviye": "Orta"
        },
        {
            "kategori": "Dijital Uyum Riski (GİB/SGK)",
            "aciklama": "SGK bildiriminde 2 personel için eksik gün bildirimi.",
            "seviye": "Düşük"
        },
    ]
    # Rasgele 2–3 tanesini dönelim
    return random.sample(alerts, k=random.randint(2, 3))

