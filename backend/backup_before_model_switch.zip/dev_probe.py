import json
from connectors.luca_client import fetch_mizan, fetch_beyanlar, ping as luca_ping
from connectors.banka_client import fetch_ekstre, ping as banka_ping

period = "2025-Q4"

print("== LUCA PING ==")
print(json.dumps(luca_ping(), ensure_ascii=False, indent=2))

print("\n== LUCA MİZAN ==")
mizan = fetch_mizan(period)
print(json.dumps({
  "borc_toplam": mizan.get("borc_toplam"),
  "alacak_toplam": mizan.get("alacak_toplam"),
  "dengeli": mizan.get("dengeli"),
  "rows_sample": mizan.get("rows", [])[:2]
}, ensure_ascii=False, indent=2))

print("\n== LUCA BEYANLAR ==")
beyan = fetch_beyanlar(period)
print(json.dumps(beyan[:3], ensure_ascii=False, indent=2))

print("\n== BANKA PING ==")
print(json.dumps(banka_ping(), ensure_ascii=False, indent=2))

print("\n== BANKA EKSTRE (son 7 gün) ==")
ekstre = fetch_ekstre(last_n_days=7)
print(json.dumps(ekstre, ensure_ascii=False, indent=2))
