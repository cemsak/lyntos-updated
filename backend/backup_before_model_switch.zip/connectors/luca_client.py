# ~/lyntos/backend/connectors/luca_client.py
import os, csv
from pathlib import Path
from typing import List, Dict, Any

# .env: LUCA_MODE=csv | api
# .env: LUCA_CSV_MIZAN_PATH, LUCA_CSV_BEYAN_PATH (opsiyonel)
BASE_DIR = Path(__file__).resolve().parents[1]  # backend/
DEFAULT_MIZAN = BASE_DIR / "connectors" / "data" / "luca_mizan.csv"
DEFAULT_BEYAN = BASE_DIR / "connectors" / "data" / "luca_beyan.csv"

def _read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def get_mizan(firma: str, period: str) -> Dict[str, Any]:
    """
    CSV varsa CSV'den, yoksa güvenli mock döner.
    Dönüş: {"borc_toplam": float, "alacak_toplam": float, "dengeli": bool}
    """
    mode = os.getenv("LUCA_MODE", "csv").lower()
    if mode == "csv":
        csv_path = Path(os.getenv("LUCA_CSV_MIZAN_PATH", str(DEFAULT_MIZAN)))
        rows = _read_csv(csv_path)
        # period & firma eşleşen satır(lar)ı toparla
        borc = 0.0
        alacak = 0.0
        matched = False
        for r in rows:
            if r.get("period") == period and r.get("firma") == firma:
                matched = True
                try:
                    borc += float(r.get("borc_toplam", "0") or 0)
                    alacak += float(r.get("alacak_toplam", "0") or 0)
                except ValueError:
                    pass
        if matched:
            return {
                "borc_toplam": round(borc, 2),
                "alacak_toplam": round(alacak, 2),
                "dengeli": abs(borc - alacak) < 0.01,
            }
        # Eşleşme yoksa mock
    # API modu ileride eklenecek
    return {
        "borc_toplam": 420000.50,
        "alacak_toplam": 420000.50,
        "dengeli": True,
    }

def get_beyan_ozeti(firma: str, period: str) -> List[Dict[str, str]]:
    """
    CSV varsa CSV'den, yoksa güvenli mock döner.
    Dönüş: [{"ad","durum","risk"}...]
    """
    mode = os.getenv("LUCA_MODE", "csv").lower()
    if mode == "csv":
        csv_path = Path(os.getenv("LUCA_CSV_BEYAN_PATH", str(DEFAULT_BEYAN)))
        rows = _read_csv(csv_path)
        out: List[Dict[str, str]] = []
        for r in rows:
            if r.get("period") == period and r.get("firma") == firma:
                out.append({
                    "ad": r.get("ad", ""),
                    "durum": r.get("durum", ""),
                    "risk": r.get("risk", ""),
                })
        if out:
            return out
        # Eşleşme yoksa mock
    # API modu ileride eklenecek
    return [
        {"ad":"KDV Beyannamesi","durum":"Onaylandı","risk":"Düşük"},
        {"ad":"Muhtasar","durum":"Bekliyor","risk":"Orta"},
        {"ad":"Geçici Vergi","durum":"Hazırlanıyor","risk":"Orta"},
    ]

