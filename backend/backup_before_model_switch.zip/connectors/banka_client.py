# ~/lyntos/backend/connectors/banka_client.py
import os, csv
from pathlib import Path
from typing import List, Dict, Any
from collections import defaultdict

# .env: BANKA_MODE=csv | api
# .env: BANKA_CSV_PATH (opsiyonel)
BASE_DIR = Path(__file__).resolve().parents[1]  # backend/
# Var olan demoya uyum: eski dosya varsa onu kullan, yoksa data/banka_hareket.csv
LEGACY_DEMO = BASE_DIR / "connectors" / "banka" / "banka_demo.csv"
DEFAULT_CSV = BASE_DIR / "connectors" / "data" / "banka_hareket.csv"

def _resolve_csv_path() -> Path:
    env_path = os.getenv("BANKA_CSV_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return p
    if LEGACY_DEMO.exists():
        return LEGACY_DEMO
    return DEFAULT_CSV

def _read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def get_banka_ozet(firma: str, period: str) -> Dict[str, Any]:
    """
    CSV varsa CSV'den bankalara göre toplam bakiye hesaplar.
    Dönüş:
      {
        "toplam_bakiye": float,
        "gunluk_nakit_akisi": float,   # basit tahmin (son iki satır farkı)
        "detaylar": [{"banka","bakiye"}...]
      }
    """
    mode = os.getenv("BANKA_MODE", "csv").lower()
    if mode == "csv":
        csv_path = _resolve_csv_path()
        rows = _read_csv(csv_path)

        # Beklenen minimum kolonlar:
        # banka, bakiye, period, firma  (firma/period yoksa tüm satırları toplar)
        agg = defaultdict(float)
        seq: List[float] = []

        for r in rows:
            if (firma and r.get("firma") and r.get("firma") != firma):
                continue
            if (period and r.get("period") and r.get("period") != period):
                continue
            try:
                bakiye = float(r.get("bakiye", "0") or 0)
            except ValueError:
                bakiye = 0.0
            bank = r.get("banka", "Banka")
            agg[bank] += bakiye
            seq.append(bakiye)

        detaylar = [{"banka": k, "bakiye": round(v, 2)} for k, v in agg.items()]
        toplam = round(sum(v for v in agg.values()), 2)
        gunluk = 0.0
        if len(seq) >= 2:
            gunluk = round(seq[-1] - seq[-2], 2)

        if detaylar:
            return {
                "toplam_bakiye": toplam,
                "gunluk_nakit_akisi": gunluk if gunluk != 0.0 else 30410.25,  # varsayılan
                "detaylar": detaylar
            }

    # CSV veya API yoksa mock güvenli dönüş
    return {
        "toplam_bakiye": 248680.85,
        "gunluk_nakit_akisi": 30410.25,
        "detaylar": [
            {"banka": "Garanti BBVA", "bakiye": 125430.75},
            {"banka": "İş Bankası",   "bakiye": 89050.10},
            {"banka": "Ziraat",       "bakiye": 34200.00},
        ],
    }

